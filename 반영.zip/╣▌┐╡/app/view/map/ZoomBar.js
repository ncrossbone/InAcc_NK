Ext.define("InAcc.view.map.ZoomBar", {
	
	extend: "Ext.Component",
	
	xtype: "inacc-zoomBar",
	
	//title: "확대/축소 바",
	//header: false,
	
	style: {
		"z-index": 99999
	},
	
	layout: {
		type: "absolute"
	},
	
	x: 50,
	y: 50,
	
	width: 60,
	height: 200,
	
	html: 	"fjaslkdjfdlskjflk",
});