Ext.define("InAcc.view.east.EastContainer", {
	
	extend: "Ext.window.Window",
	
	xtype: "inacc-eastcontainer",
	height:390,
	width:400,
	x:1520,
	y:36,
	
	items:[{
		xtype:"container",
		width:200,
		height:36
	}]
});